EduCity third-floor tracing review — Draft 05 / 3 November 2026

REVISION 05
The satellite overlay reaches the complete outer roof edge, including the blue
street-side roof strip. The local room geometry and exit-sign positions are preserved.

REVISION 04
The corrected Exit sign Complete.jpg is the current exit-sign reference.
There are 17 signs, with provisional anticlockwise ES IDs.
The middle connector sign is removed, the left connector sign is repositioned,
and the U09, U17 and P2 partition signs are included.
Original icons and their displayed orientations are copied from the corrected reference.
FW Adv id, site_id and geographic egress bearings are unassigned.
The floor-plan compass retains its north-up satellite roof-axis match.
Use the View selector to inspect the north-up satellite overlay.
This is a visual image fit, not a surveyed footprint or geographic coordinate set.

REVISION 02
Added the zone letters and names from the supplied reference directly on the plan:
D Connection to ICT-City / yhdyskäytävä; O Study space / opiskelutila;
P Workspace / työtila; Q Cafeteria / kahvio; R Terrace / terassi.
The reference zones are also listed in the HTML and bilingual CSV register.
Existing region boundaries, region IDs and source linework are preserved.

Open EduCity_F3_Trace_Review.html in a browser. It is self-contained and works offline.
Use the source opacity slider, trace-only / source-only / overlay buttons, and click regions.

The SVG contains source-derived vector outlines and manually constructed region rings.
The full source linework retains visible stairs, landings, door swings, furniture and fine partitions.
Pixel outlines are intentionally not represented as surveyed wall centre lines.
The DXF contains only editable semantic region outlines, not the fine source linework.
The JSON is the authoritative draft tracing dataset. Both CSVs open in Excel.

COORDINATES
Local origin is source image pixel (857,70); local x right, local y down.
Source screenshot is 1537 x 916 pixels. The connection is cropped at local x=-88.
DXF flips y for CAD and uses unitless pixels. It is not in metres.
No latitude/longitude, metric scale or surveyed elevation is assigned.
North orientation is approximate, based on visual satellite matching.
The Maps URL's building pin (60.4486861 N,22.2974464 E) is a reference only.

IDENTITIES
F3 is the floor identified by the user; the screenshot itself is unnumbered.
O=study; P=workspace; Q=cafeteria; R=terrace; D=ICT-City connection.
New local provisional IDs do not reuse 7 City Road's V0000010 site identity.
Room functions not labelled in the source are left unlabelled.
Open access between O and P is shown by a logical zone division, not a new wall.
Grey / white central features and lower-right outline remain unclassified.
Exit-sign positions are transferred from the user-marked image.
No geographic egress bearings or evacuation routes are invented.

NEXT CONTROLLED STEP
Review region boundaries and central features, then register the approved plan to
surveyed controls or an authoritative footprint. Use two points for a similarity
transform or three non-collinear points for an affine transform; verify on further controls.
Continue to physical exit-sign placement only after the zones are approved.

SOURCES
Supplied screenshot: Screenshot 2026-11-03 at 12.26.21 AM.png
Google Maps reference supplied by the user; URL retained in Trace_Data.json.
Official campus address: https://www.turkuamk.fi/en/about-us/campuses/kupittaa-campus/

SATELLITE ALIGNMENT
Plan up bearing: 38.60 degrees east of true north (visual).
Matrix and visual control points are retained in Trace_Data.json.
Image: Google Maps; imagery attribution retained in the complete screenshot.
The small control residual measures image fitting only, not geographic accuracy.
