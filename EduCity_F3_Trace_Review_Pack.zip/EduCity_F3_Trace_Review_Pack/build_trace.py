from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, csv, base64, hashlib, shutil, zipfile, html, math
import numpy as np

ROOT=Path('/workspace/scratch/79d839b93b3a')
OUT=ROOT/'outputs/educity_f3'
SRC=ROOT/'upload/Screenshot 2026-11-03 at 12.26.21\u202fAM.png'
OUT.mkdir(parents=True,exist_ok=True)
im=Image.open(SRC).convert('RGB')
# Local source pixels: origin (857,70) in the unmodified 1537 x 916 source.
OX,OY=857,70
zones=[]
palette={'study':'#7ecac6','workspace':'#f1bc88','cafeteria':'#ebd687','terrace':'#a9cf9a','stair':'#b9bdc6','lift':'#b9a4dc','wc':'#a6cbe4','room':'#e1e4e9','connection':'#84badb','unclassified':'#c9c8c7','roof':'#e7e5df'}
def rect(x1,y1,x2,y2): return [[x1,y1],[x2,y1],[x2,y2],[x1,y2]]
def add(code,name,kind,outer,holes=None,label=None,source_letter='',note=''):
    zones.append(dict(id='EDU-F3-'+code,name=name,kind=kind,source_letter=source_letter,
       rings=[outer]+(holes or []),label=label or [sum(p[0] for p in outer)/len(outer),sum(p[1] for p in outer)/len(outer)],
       status='draft_for_review', boundary_basis='manual source-image trace',note=note,
       color=palette[kind], longitude=None,latitude=None))

# Named open areas are logical zones; subdivision across open access is not a wall.
add('O1','Study space • left wing','study',[[0,0],[215,0],[215,240],[153,240],[153,296],[215,296],[215,380],[138,380],[138,281],[89,281],[89,380],[69,380],[69,185],[0,185]],
    [rect(89,65,189,107),rect(89,126,138,218)], [39,108],'O', 'Open boundary to P1 at y=380 is a review subdivision, not a wall.')
add('O2','Study space • right wing','study',[[417,0],[563,0],[563,363],[487,363],[487,305],[417,305],[417,107],[487,107],[487,65],[417,65]],
    [rect(503,126,544,185),rect(503,207,544,278)], [462,185],'O','Open boundary to P2 is a review subdivision.')
add('P1','Workspace • left wing','workspace',[[69,380],[215,380],[215,597],[0,597],[0,556],[69,556]],label=[164,487],source_letter='P')
add('P2','Workspace • right wing','workspace',rect(417,363,563,515),label=[466,480],source_letter='P',note='Open access to O2; source right-side office retained separately.')
add('Q1','Cafeteria','cafeteria',[[69,597],[89,597],[89,703],[138,703],[138,597],[215,597],[215,800],[69,800]],label=[174,758],source_letter='Q')
add('R1','Terrace','terrace',[[215,597],[417,597],[417,515],[632,515],[632,666],[430,666],[430,800],[215,800]],label=[322,707],source_letter='R',note='Hatched outdoor area; planting outlines retained in source linework.')
add('D1','Connection to ICT-City','connection',rect(-88,380,69,423),label=[-35,401],source_letter='D',note='Drawing cropped at x=-88; continues beyond the image.')

# Wall-bounded enclosures, with no invented room function.
for code,box in [('U01',(89,65,125,107)),('U02',(125,65,163,107)),('U03',(163,65,189,107)),
                 ('U04',(89,126,138,168)),('U05',(89,168,138,199)),('U06',(89,199,138,218)),
                 ('U07',(0,185,69,218)),('U08',(0,218,69,302)),('U09',(153,240,246,296)),
                 ('U10',(0,465,69,556)),('U11',(563,448,632,515)),('U12',(0,597,69,697)),
                 ('U13',(0,697,69,735)),('U14',(563,70,632,218)),('U15',(563,218,632,302)),
                 ('U16',(503,126,544,185))]:
    add(code,'Unlabelled enclosure '+code[1:],'room',rect(*box),note='Function not identified in supplied plan; enclosure interpretation needs review.')
add('N1','Northern central area','room',[[215,0],[417,0],[417,65],[355,65],[355,107],[308,107],[308,65],[215,65]],label=[315,30],note='No function label; central circulation/enclosure boundary requires confirmation.')
add('N2','Central northern enclosure','room',rect(215,107,417,206),label=[316,157])
for code,box in [('N3',(215,65,274,107)),('N4',(274,65,308,86)),('N5',(274,86,308,107)),
                 ('N6',(355,65,390,86)),('N7',(355,86,390,107)),('N8',(390,65,417,107)),
                 ('N9',(417,65,450,107)),('N10',(450,65,487,107))]:
    add(code,'Unlabelled northern enclosure '+code[1:],'room',rect(*box),note='Small enclosure; use not labelled. Partitions traced from screenshot.')
add('U17','Unlabelled central-right enclosure','room',rect(386,305,487,363),label=[435,334])

# Stairs, lifts and toilet banks are traced as core polygons; detailed symbols
# remain in the pixel-derived vector linework rather than being guessed anew.
for n,box in enumerate([(0,302,69,380),(563,302,632,380),(0,735,69,800),(563,0,632,70)],1):
    add(f'S{n:02}','Stair core '+str(n),'stair',rect(*box),note='Stair symbol visible; flight direction, levels served and dimensions unconfirmed.')
for n,box in enumerate([(0,423,36,465),(36,423,69,465),(563,423,598,448),(598,423,632,448)],1):
    add(f'L{n:02}','Lift shaft '+str(n),'lift',rect(*box),note='Lift symbol visible; numbering is provisional.')
add('H1','Right lift lobby','connection',rect(563,380,632,423),label=[598,399])
for n,box in enumerate([(89,281,138,380),(503,207,544,278),(89,597,138,703)],1):
    add(f'WC{n:02}','Toilet / service bank '+str(n),'wc',rect(*box),note='Bank outline only; internal cubicles and doors retained in vector linework.')
add('C1','Central grey feature • upper','unclassified',[[215,206],[273,206],[273,273],[247,299],[247,368],[417,368],[417,400],[215,400],[215,296],[246,296],[246,240],[215,240]],label=[231,340],note='Grey area is not classified as floor, void or circulation without confirmation.')
add('C2','Central white feature • upper','unclassified',[[273,206],[417,206],[417,283],[407,283],[386,305],[386,363],[417,363],[417,368],[247,368],[247,299],[273,273]],label=[330,285],note='Unlabelled central white area; walkability unknown. Small chamfer follows source grey edge.')
add('B1','Central connecting strip','connection',rect(215,400,417,423),label=[315,412],note='Apparent cross-floor connection; doorway / route status requires confirmation.')
add('C3','Central grey feature • lower','unclassified',[[215,423],[246,423],[246,494],[251,494],[251,564],[417,564],[417,597],[215,597]],label=[235,540],note='Grey band; function and walkability unconfirmed.')
add('C4','Central white feature • lower','unclassified',[[246,423],[417,423],[417,564],[251,564],[251,494],[246,494]],label=[330,495],note='Unlabelled central area; not assumed walkable.')
add('RF1','Lower-right outlined area','roof',rect(430,666,632,800),label=[535,742],note='Unhatched area below terrace; floor / roof / void classification unconfirmed.')

# Zone labels are taken from the reference legend, only where its letters
# actually appear in this floor image. The existing rings and IDs are retained.
reference_legend=[
    dict(letter='D',english='Connection to ICT-City',finnish='yhdyskäytävä'),
    dict(letter='O',english='Study space',finnish='opiskelutila'),
    dict(letter='P',english='Workspace',finnish='työtila'),
    dict(letter='Q',english='Cafeteria',finnish='kahvio'),
    dict(letter='R',english='Terrace',finnish='terassi')]
legend_by_letter={x['letter']:x for x in reference_legend}
reference_labels={
    'O1':([106,32],['O · Study space','opiskelutila']),
    'O2':([458,175],['O','Study space','opiskelutila']),
    'P1':([176,478],['P','Workspace','työtila']),
    'P2':([465,477],['P · Workspace','työtila']),
    'Q1':([174,748],['Q','Cafeteria','kahvio']),
    'R1':([322,701],['R · Terrace','terassi']),
    'D1':([-42,389],['D · Connection','to ICT-City','yhdyskäytävä'])}
for z in zones:
    if z['source_letter']:
        ref=legend_by_letter[z['source_letter']]
        z['source_name_en']=ref['english'];z['source_name_fi']=ref['finnish']
        z['label'],z['display_label_lines']=reference_labels[z['id'].replace('EDU-F3-','')]

# Extract all neutral dark linework, retaining door arcs, stair risers, furniture
# and thin partitions exactly at the supplied raster resolution. Magenta POIs
# are excluded. Adjacent equal horizontal runs merge into vector rectangles.
crop=im.crop((769,70,1491,872))
a=np.asarray(crop)
dark=(a.max(axis=2)-a.min(axis=2)<32)&(a.mean(axis=2)<195)
tones=np.where(dark,np.where(a.mean(axis=2)<100,40,np.where(a.mean(axis=2)<145,115,170)),0).astype(np.uint8)
runs=[]; active={}
for y,row in enumerate(tones):
    padded=np.r_[0,row,0].astype(np.int16)
    edges=np.where(np.diff(padded)!=0)[0]
    current={}
    for x1,x2 in zip(edges[:-1],edges[1:]):
        tone=int(row[x1])
        if tone==0:continue
        key=(int(x1),int(x2),tone)
        if key in active: current[key]=active.pop(key)
        else: current[key]=y
    for (x1,x2,tone),y1 in active.items(): runs.append([x1-88,y1,x2-x1,y-y1,tone])
    active=current
for (x1,x2,tone),y1 in active.items(): runs.append([x1-88,y1,x2-x1,len(dark)-y1,tone])

meta=dict(title='EduCity • third floor trace',building='EduCity',address='Joukahaisenkatu 7, Turku, Finland',level_id='F3',
    level_basis='Third floor as identified by user; not independently confirmed from unnumbered source image',
    status='Draft for source-image review',date='2026-11-03',source_image_size=list(im.size),
    coordinate_system=dict(type='local image coordinates',unit='source pixel',origin_source_image=[OX,OY],x_axis='right',y_axis='down',georeferenced=False,north='unconfirmed',scale='unconfirmed'),
    location_reference=dict(latitude=60.4486861,longitude=22.2974464,meaning='Building place pin supplied in Google Maps URL; not a surveyed control point'),
    georeferencing_requirements='Two surveyed points plus a similarity assumption, or three non-collinear control points for an affine fit; check against further points.',
    method='Manual orthogonal region rings plus pixel-derived neutral linework vector outlines. Labels copied only where visible. No emergency exit signs are inferred.',
    vectorization=dict(threshold=195,neutral_channel_spread_less_than=32,rectangle_count=len(runs),source_crop=[769,70,1491,872]),
    sources=[dict(name=SRC.name,type='user supplied screenshot'),dict(name='Google Maps reference',url='https://www.google.com/maps/place/EduCity/@60.4481366,22.2970462,198m/data=!3m1!1e3!4m14!1m7!3m6!1s0x468c773fd8c0b667:0xfdf1a5288c7f2ebb!2sEduCity!8m2!3d60.4486861!4d22.2974464!16s%2Fg%2F11hk90v9nl'),dict(name='Turku UAS campus address',url='https://www.turkuamk.fi/en/about-us/campuses/kupittaa-campus/')])
meta['revision']='Draft 02 — reference zone labels'
meta['reference_zone_letters_present']=['D','O','P','Q','R']
dataset=dict(metadata=meta,reference_legend=reference_legend,zones=zones,source_linework_rectangles=runs)
(OUT/'EduCity_F3_Trace_Data.json').write_text(json.dumps(dataset,ensure_ascii=False,indent=2))
with (OUT/'EduCity_F3_Zone_Register.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['level_id','zone_id','name','category','source_letter','source_name_en','source_name_fi','status','longitude','latitude','notes'])
    for z in zones:w.writerow(['F3',z['id'],z['name'],z['kind'],z['source_letter'],z.get('source_name_en',''),z.get('source_name_fi',''),z['status'],'','',z['note']])
with (OUT/'EduCity_F3_Vertices.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['level_id','zone_id','ring_index','ring_role','vertex_no','local_x_px','local_y_px','source_x_px','source_y_px','longitude','latitude'])
    for z in zones:
        for ri,ring in enumerate(z['rings']):
            for i,(x,y) in enumerate(ring,1):w.writerow(['F3',z['id'],ri,'outer' if ri==0 else 'hole',i,x,y,x+OX,y+OY,'',''])

def path(rings):
    return ' '.join('M'+' L'.join(f'{x},{y}' for x,y in r)+' Z' for r in rings)
def svg_content(labels=True):
    s=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="-108 -25 764 851" width="764" height="851" role="img" aria-label="EduCity third floor draft trace">',
       '<rect x="-108" y="-25" width="764" height="851" fill="white"/>',
       '<g id="zones" fill-rule="evenodd" stroke-width="1.1" stroke="#53667a" stroke-opacity=".65">']
    for z in zones:s.append(f'<path data-id="{z["id"]}" d="{path(z["rings"])}" fill="{z["color"]}" fill-opacity=".34"><title>{html.escape(z["id"]+" — "+z["name"])}</title></path>')
    s+=['</g><g id="linework" fill="#202326" opacity=".82">']
    for x,y,w,h,tone in runs:s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="rgb({tone},{tone},{tone})"/>')
    s+=['</g>']
    if labels:
        s.append('<g id="labels" font-family="Arial,sans-serif" font-size="8" font-weight="700" text-anchor="middle" fill="#19364c" paint-order="stroke" stroke="white" stroke-width="2.8" stroke-linejoin="round">')
        for z in zones:
            x,y=z['label'];short=z['id'].replace('EDU-F3-','')
            if z.get('display_label_lines'):
                for i,line in enumerate(z['display_label_lines']):
                    size=7.5 if i==len(z['display_label_lines'])-1 else 9.5
                    color='#9e176e' if i==0 else '#19364c'
                    s.append(f'<text class="reference-zone-label" data-zone="{z["id"]}" x="{x}" y="{y+i*11}" font-size="{size}" fill="{color}" dominant-baseline="middle">{html.escape(line)}</text>')
            else:
                s.append(f'<text x="{x}" y="{y}" dominant-baseline="middle">{short}</text>')
        s.append('</g>')
    s.append('</svg>');return '\n'.join(s)
svg=svg_content()
(OUT/'EduCity_F3_Traced_Plan.svg').write_text(svg)

# DXF uses unitless source pixels with Y flipped so ordinary CAD has Y up.
dxf=['0','SECTION','2','HEADER','9','$INSUNITS','70','0','0','ENDSEC','0','SECTION','2','ENTITIES']
for z in zones:
    for ring in z['rings']:
        dxf+=['0','POLYLINE','8',z['id'],'66','1','70','1']
        for x,y in ring:dxf+=['0','VERTEX','8',z['id'],'10',str(x),'20',str(-y),'30','0']
        dxf+=['0','SEQEND']
    if z['source_letter']:
        x,y=z['label']
        dxf+=['0','TEXT','8','REFERENCE_ZONE_LABELS','10',str(x),'20',str(-y),'30','0','40','6','1',z['source_letter']+' - '+z['source_name_en']]
dxf+=['0','ENDSEC','0','EOF']
(OUT/'EduCity_F3_Region_Outlines.dxf').write_text('\n'.join(dxf)+'\n')

# Review UI embeds the unchanged source, so comparison remains usable offline.
encoded=base64.b64encode(SRC.read_bytes()).decode()
svg_ui=svg.replace('<g id="zones"',f'<image id="source" href="data:image/png;base64,{encoded}" x="-857" y="-70" width="1537" height="916" opacity=".28"/><g id="zones"')
page='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EduCity | Floor 3 trace review</title><style>
*{box-sizing:border-box}body{margin:0;font:14px system-ui,sans-serif;color:#19344a;background:#edf1f5}header{padding:19px 25px;background:#17374c;color:white;display:flex;align-items:center;gap:20px}h1{font-size:23px;margin:2px 0 6px}.eyebrow{font-size:11px;letter-spacing:2px;color:#a9cbd8}.badge{margin-left:auto;border:1px solid #89a6b7;padding:7px 11px;border-radius:5px;font-size:12px}main{display:grid;grid-template-columns:310px 1fr;gap:16px;padding:16px;height:calc(100vh - 98px)}aside{background:white;padding:18px;border-radius:8px;overflow:auto}h2{font-size:15px;margin:2px 0 12px}p{line-height:1.5}.muted{color:#647a89;font-size:12px}.control{margin:14px 0}.control label{display:flex;gap:9px;align-items:center}input[type=range]{width:100%;margin-top:9px}button,select,input[type=search]{font:inherit;border:1px solid #cbd5de;border-radius:5px;padding:8px;background:white;color:#19344a}button{cursor:pointer}button:hover{background:#e9f3f5}#stage{background:white;border-radius:8px;overflow:hidden;position:relative;touch-action:none}#plan{height:100%;width:100%;display:block;cursor:grab}#plan:active{cursor:grabbing}#zones path:hover,#zones path.selected{fill-opacity:.7;stroke:#007e9d;stroke-width:2.4}#labels{pointer-events:none}#linework{pointer-events:none}#source{pointer-events:none}#details{background:#f1f6f9;border-radius:5px;padding:12px;font-size:12px;line-height:1.5;margin:16px 0}#zoneList{max-height:260px;overflow:auto;border-top:1px solid #e2e9ee;margin-top:9px}.zoneRow{display:block;text-align:left;width:100%;border:none;border-bottom:1px solid #edf1f5;border-radius:0;padding:9px 3px;font-size:12px}.swatch{display:inline-block;width:11px;height:11px;margin-right:7px;border:1px solid #9badb7}.toolbar{position:absolute;right:14px;top:13px;display:flex;gap:6px}.notice{padding:10px 12px;background:#fff5db;border-left:3px solid #d2aa49;font-size:12px;line-height:1.5;margin:13px 0}.count{font-size:12px;color:#647a89;margin:8px 0}.links a{color:#126a89}#coord{position:absolute;bottom:12px;left:16px;background:#ffffffed;border:1px solid #dce4e9;padding:6px 9px;border-radius:4px;font-size:11px}@media(max-width:850px){main{grid-template-columns:1fr;height:auto}aside{order:2}#stage{height:78vh}.badge{display:none}}@media print{aside,header,.toolbar,#coord{display:none}main{display:block;height:auto;padding:0}#stage{height:95vh}}
</style></head><body><header><div><div class="eyebrow">INDOORSOS · SOURCE TRACE REVIEW</div><h1>EduCity — Third floor</h1><div style="font-size:12px;color:#c0d4dd">Joukahaisenkatu 7 · Turku, Finland</div></div><span class="badge">DRAFT 01 · 03 NOV 2026</span></header><main><aside><h2>Compare the trace</h2><p class="muted">Click a zone to inspect its identity. Scroll to zoom; drag to pan. The source and vector trace share the same pixel coordinates.</p><div class="control"><label><input id="showZones" type="checkbox" checked> Zone polygons</label></div><div class="control"><label><input id="showLines" type="checkbox" checked> Vector source linework</label></div><div class="control"><label><input id="showLabels" type="checkbox" checked> Zone IDs</label></div><div class="control"><label for="sourceOpacity">Original image opacity <span id="opacityValue">28%</span></label><input id="sourceOpacity" type="range" min="0" max="100" value="28"></div><div style="display:flex;gap:7px"><button id="traceOnly">Trace only</button><button id="sourceOnly">Source only</button><button id="compare">Overlay</button></div><div class="notice"><b>Image coordinates only.</b> Scale and true north are unconfirmed. The Google place pin is a location reference, not a plan control point. F3 follows your floor identification.</div><div id="details">Select a polygon or a register entry below.</div><h2>Zone register</h2><input id="filter" type="search" placeholder="Find O1, stair, terrace…" style="width:100%"><div class="count" id="count"></div><div id="zoneList"></div><p class="muted">O study space · P workspace · Q cafeteria · R terrace · D ICT-City connection. Unlabelled rooms use provisional IDs. Open-zone subdivisions do not imply walls.</p><p class="muted">Central grey and white features remain unclassified. Door arcs, stair risers and furniture follow the source linework. No exit signs or safe routes have been inferred.</p><p class="links muted"><a href="https://www.turkuamk.fi/en/about-us/campuses/kupittaa-campus/" target="_blank" rel="noreferrer">Turku UAS campus reference</a></p></aside><section id="stage">SVG_PLACEHOLDER<div class="toolbar"><button id="plus" aria-label="Zoom in">+</button><button id="minus" aria-label="Zoom out">−</button><button id="reset">Fit plan</button></div><div id="coord">Source coordinates · pixels · north unconfirmed</div></section></main><script>
const zones=DATA_PLACEHOLDER;const plan=document.querySelector('svg');plan.id='plan';let box=[-108,-25,764,851];const home=[...box];function apply(){plan.setAttribute('viewBox',box.join(' '))}const byId=id=>document.getElementById(id);function sync(){byId('zones').style.display=byId('showZones').checked?'':'none';byId('linework').style.display=byId('showLines').checked?'':'none';byId('labels').style.display=byId('showLabels').checked?'':'none';byId('source').setAttribute('opacity',byId('sourceOpacity').value/100);byId('opacityValue').textContent=byId('sourceOpacity').value+'%'}['showZones','showLines','showLabels','sourceOpacity'].forEach(id=>byId(id).addEventListener('input',sync));function preset(z,l,b,o){byId('showZones').checked=z;byId('showLines').checked=l;byId('showLabels').checked=b;byId('sourceOpacity').value=o;sync()}byId('traceOnly').onclick=()=>preset(true,true,true,0);byId('sourceOnly').onclick=()=>preset(false,false,false,100);byId('compare').onclick=()=>preset(true,true,true,40);function select(z){document.querySelectorAll('#zones path').forEach(p=>p.classList.toggle('selected',p.dataset.id===z.id));byId('details').replaceChildren();const strong=document.createElement('strong');strong.textContent=z.id+' · '+z.name;byId('details').append(strong,document.createElement('br'),document.createTextNode(z.note||'Source-image boundary trace; review pending.'),document.createElement('br'),document.createTextNode('Coordinates: source pixels · longitude/latitude unassigned.'))}zones.forEach(z=>{const p=document.querySelector('[data-id="'+z.id+'"]');p.addEventListener('click',()=>{if(!moved)select(z)})});function list(){const q=byId('filter').value.toLowerCase();byId('zoneList').replaceChildren();const filtered=zones.filter(z=>(z.id+' '+z.name).toLowerCase().includes(q));byId('count').textContent=filtered.length+' of '+zones.length+' regions';filtered.forEach(z=>{const b=document.createElement('button');b.className='zoneRow';const s=document.createElement('span');s.className='swatch';s.style.background=z.color;b.append(s,document.createTextNode(z.id.replace('EDU-F3-','')+' · '+z.name));b.onclick=()=>select(z);byId('zoneList').append(b)})}byId('filter').oninput=list;list();function zoom(f){const cx=box[0]+box[2]/2,cy=box[1]+box[3]/2;box[2]*=f;box[3]*=f;box[0]=cx-box[2]/2;box[1]=cy-box[3]/2;apply()}byId('plus').onclick=()=>zoom(.8);byId('minus').onclick=()=>zoom(1.25);byId('reset').onclick=()=>{box=[...home];apply()};plan.addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY>0?1.1:.9)},{passive:false});let drag=null,moved=false;plan.addEventListener('pointerdown',e=>{drag=[e.clientX,e.clientY,...box];moved=false});window.addEventListener('pointerup',()=>{drag=null});plan.addEventListener('pointermove',e=>{const point=new DOMPoint(e.clientX,e.clientY).matrixTransform(plan.getScreenCTM().inverse());byId('coord').textContent='Local x '+point.x.toFixed(1)+' / y '+point.y.toFixed(1)+' px · source '+(point.x+857).toFixed(1)+', '+(point.y+70).toFixed(1);if(!drag)return;let dx=e.clientX-drag[0],dy=e.clientY-drag[1];if(Math.abs(dx)+Math.abs(dy)>3)moved=true;let s=plan.getScreenCTM().a;box[0]=drag[2]-dx/s;box[1]=drag[3]-dy/s;apply()});sync();
</script></body></html>'''
page=page.replace('SVG_PLACEHOLDER',svg_ui).replace('DATA_PLACEHOLDER',json.dumps(zones,ensure_ascii=False))
legend_rows=''.join('<tr><td style="color:#9e176e;font-weight:700;padding:6px 8px 6px 0">'+r['letter']+'</td><td style="padding:6px 0">'+html.escape(r['english'])+'<br><span class="muted">'+html.escape(r['finnish'])+'</span></td></tr>' for r in reference_legend)
legend_html='<h2>Reference zones</h2><table style="font-size:12px;width:100%;border-collapse:collapse">'+legend_rows+'</table><p class="muted">These are the reference letters visible on this floor. Repeated O and P areas keep their separate trace IDs.</p>'
page=page.replace('DRAFT 01 · 03 NOV 2026','DRAFT 02 · 03 NOV 2026').replace('> Zone IDs</label>','> Zone names and IDs</label>').replace('<div id="details">',legend_html+'<div id="details">')
page=page.replace("strong.textContent=z.id+' · '+z.name;","strong.textContent=z.id+' · '+z.name+(z.source_name_fi?' / '+z.source_name_fi:'');")
(OUT/'EduCity_F3_Trace_Review.html').write_text(page)

# Explicit geometric checks; no claim of validated evacuation or geographic data.
def orient(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def proper_cross(a,b,c,d):return orient(a,b,c)*orient(a,b,d)<0 and orient(c,d,a)*orient(c,d,b)<0
issues=[]
for z in zones:
    for ri,r in enumerate(z['rings']):
        area=abs(sum(r[i][0]*r[(i+1)%len(r)][1]-r[(i+1)%len(r)][0]*r[i][1] for i in range(len(r)))/2)
        if area<=0:issues.append([z['id'],ri,'zero_area'])
        for i in range(len(r)):
            for j in range(i+1,len(r)):
                if j==i+1 or (i==0 and j==len(r)-1):continue
                if proper_cross(r[i],r[(i+1)%len(r)],r[j],r[(j+1)%len(r)]):issues.append([z['id'],ri,'self_intersection'])
qa=dict(region_count=len(zones),unique_region_ids=len(set(z['id'] for z in zones))==len(zones),
    ring_checks=issues,source_vector_rectangles=len(runs),geographic_coordinates_assigned=False,
    not_validated=['Metric scale','True north','Surveyed georeferencing','Floor identification','Door clear widths','Exit signs','Route connectivity and emergency suitability','Unlabelled and central-feature semantics'],
    note='Checks cover digitised region rings only. Source-image trace is a draft; region subdivisions are provisional.')
(OUT/'QA.json').write_text(json.dumps(qa,indent=2))
readme='''EduCity third-floor tracing review — Draft 02 / 3 November 2026

REVISION 02
Added the zone letters and names from the supplied reference directly on the plan:
D Connection to ICT-City / yhdyskäytävä; O Study space / opiskelutila;
P Workspace / työtila; Q Cafeteria / kahvio; R Terrace / terassi.
The reference zones are also listed in the HTML and bilingual CSV register.
Existing region boundaries, region IDs and source linework are preserved.

Open EduCity_F3_Trace_Review.html in a browser. It is self-contained and works offline.
Use the source opacity slider, trace-only / source-only / overlay buttons, and click regions.

The SVG contains source-derived vector outlines and manually constructed region rings.
The full source linework retains visible stairs, landings, door swings, furniture and fine partitions.
Pixel outlines are intentionally not represented as surveyed wall centre lines.
The DXF contains only editable semantic region outlines, not the fine source linework.
The JSON is the authoritative draft tracing dataset. Both CSVs open in Excel.

COORDINATES
Local origin is source image pixel (857,70); local x right, local y down.
Source screenshot is 1537 x 916 pixels. The connection is cropped at local x=-88.
DXF flips y for CAD and uses unitless pixels. It is not in metres.
No latitude/longitude, metric scale, true north or surveyed elevation is assigned.
The Maps URL's building pin (60.4486861 N,22.2974464 E) is a reference only.

IDENTITIES
F3 is the floor identified by the user; the screenshot itself is unnumbered.
O=study; P=workspace; Q=cafeteria; R=terrace; D=ICT-City connection.
New local provisional IDs do not reuse 7 City Road's V0000010 site identity.
Room functions not labelled in the source are left unlabelled.
Open access between O and P is shown by a logical zone division, not a new wall.
Grey / white central features and lower-right outline remain unclassified.
No physical exit-sign positions, egress bearings or evacuation routes are invented.

NEXT CONTROLLED STEP
Review region boundaries and central features, then register the approved plan to
surveyed controls or an authoritative footprint. Use two points for a similarity
transform or three non-collinear points for an affine transform; verify on further controls.
Continue to physical exit-sign placement only after the zones are approved.

SOURCES
Supplied screenshot: Screenshot 2026-11-03 at 12.26.21 AM.png
Google Maps reference supplied by the user; URL retained in Trace_Data.json.
Official campus address: https://www.turkuamk.fi/en/about-us/campuses/kupittaa-campus/
'''
(OUT/'README.txt').write_text(readme)
shutil.copyfile(SRC,OUT/'EduCity_F3_Source.png')
print(json.dumps(qa))
