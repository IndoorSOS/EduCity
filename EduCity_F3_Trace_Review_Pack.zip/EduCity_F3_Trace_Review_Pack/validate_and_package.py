from pathlib import Path
import json,csv,hashlib,zipfile,shutil,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image,ImageDraw

root=Path('/workspace/scratch/79d839b93b3a')
p=root/'outputs/educity_f3'
d=json.loads((p/'EduCity_F3_Trace_Data.json').read_text())
def edge_distance(point,a,b):
    x,y=point;dx=b[0]-a[0];dy=b[1]-a[1]
    t=max(0,min(1,((x-a[0])*dx+(y-a[1])*dy)/(dx*dx+dy*dy)))
    return ((x-a[0]-t*dx)**2+(y-a[1]-t*dy)**2)**.5
def on_boundary(point,z):
    return any(edge_distance(point,r[i],r[(i+1)%len(r)])<1e-6 for r in z['rings'] for i in range(len(r)))
masks=[]
for z in d['zones']:
    m=Image.new('L',(1448,1604));a=ImageDraw.Draw(m)
    for i,r in enumerate(z['rings']):a.polygon([((x+88)*2,y*2) for x,y in r],fill=1 if i==0 else 0)
    masks.append(np.array(m)[1::2,1::2].astype(bool))
overlaps=[]
for i in range(len(masks)):
    for j in range(i):
        ys,xs=np.where(masks[i]&masks[j]);count=0
        for x,y in zip(xs,ys):
            point=(x-88+.5,y+.5)
            if not on_boundary(point,d['zones'][i]) and not on_boundary(point,d['zones'][j]):count+=1
        if count:overlaps.append([d['zones'][j]['id'],d['zones'][i]['id'],count])
qa=json.loads((p/'QA.json').read_text())
qa['interior_overlap_pairs_at_source_pixel_centres']=overlaps
qa['svg_xml_parsed']=ET.parse(p/'EduCity_F3_Traced_Plan.svg').getroot().tag.endswith('svg')
with (p/'EduCity_F3_Zone_Register.csv').open(encoding='utf-8-sig') as f:
    rows=list(csv.DictReader(f));qa['csv_zone_ids_match_json']=[r['zone_id'] for r in rows]==[z['id'] for z in d['zones']]
qa['html_contains_embedded_source']='data:image/png;base64,' in (p/'EduCity_F3_Trace_Review.html').read_text()
qa['interactive_browser_test']='Not run: browser executable not installed in local runtime. JavaScript syntax checked separately.'
assert not overlaps and not qa['ring_checks'] and qa['unique_region_ids'] and qa['csv_zone_ids_match_json']
(p/'QA.json').write_text(json.dumps(qa,indent=2))
shutil.copy(root/'educity_work/build_trace.py',p/'build_trace.py')
shutil.copy(__file__,p/'validate_and_package.py')
if (root/'educity_work/add_exits_compass.py').exists():
    shutil.copy(root/'educity_work/add_exits_compass.py',p/'add_exits_compass.py')
files=[x for x in sorted(p.iterdir()) if x.is_file() and x.suffix!='.zip' and x.name!='SHA256SUMS.txt']
(p/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(x.read_bytes()).hexdigest()+'  '+x.name for x in files)+'\n')
pack=p/'EduCity_F3_Trace_Review_Pack.zip'
with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(p.iterdir()):
        if f.is_file() and f!=pack:z.write(f,'EduCity_F3_Trace_Review_Pack/'+f.name)
with zipfile.ZipFile(pack) as z:assert z.testzip() is None
print(json.dumps({'regions':len(d['zones']),'interior_overlap_pairs':overlaps,'files':len(files)+1,'zip_bytes':pack.stat().st_size}))
